
<?php
////phpinfo();
  error_reporting(0);
  show_source(__file__);
  
  preg_replace($_GET["a"], $_GET["b"], $_GET["c"]);
  ?>
