<?php 
////phpinfo();
  error_reporting(0);
  show_source(__file__);

  $str="echo \"Hello ".$_GET['a']."!!!\";";
  eval($str);
?>
