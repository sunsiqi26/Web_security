<?php 
////phpinfo();
error_reporting(0);
show_source(__FILE__);

$a = @$_REQUEST['a'];
eval("var_dump($a);"); 
?>