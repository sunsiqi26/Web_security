<?php
error_reporting(0);
show_source(__FILE__);
foreach ($_GET as $key => $value) {
    $a = $value;
    $$$key = $value;
    $answer = $flag;
        if ($answer == "flag")
        {
            eval("phpinfo();");
        }
        else
        {
            echo "try again";
        }
      
}   
?>
