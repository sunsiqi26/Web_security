<?php
error_reporting(0);
show_source(__FILE__);

$b = '1231asdasda';
extract($_GET);

if(isset($a)&&preg_match('/^[[:graph:]]$/',$a)){
	$c = trim(file_get_contents($b));
	if($a == $c){
		eval("phpinfo();");
	}else{
		echo 'byebye';
	}
}
?>