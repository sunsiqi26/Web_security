<?php 
////phpinfo();
error_reporting(0);
show_source(__FILE__);

preg_replace("/\[(.*)\]/e","\\1",$_GET['c']);
?>