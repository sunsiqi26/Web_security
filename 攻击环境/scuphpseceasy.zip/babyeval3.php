<?php
  ////phpinfo();
  error_reporting(0);
  show_source(__file__);

  $a = $_GET['a'];
  eval("'".$a."'");
?> 
