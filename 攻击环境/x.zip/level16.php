<!DOCTYPE html><!--STATUS OK--><html>
<head>
<meta http-equiv="content-type" content="text/html;charset=utf-8">
<script>
window.alert = function()  
{     
confirm("完成的不错！");
 window.location.href="level17.php?writing=wait"; 
}
</script>
<title>欢迎来到level16</title>
</head>
<body>
<h1 align=center>level16</h1>
<h1 align=center>alert不见了</h1>
<?php 
error_reporting(0);
if (preg_match('/alert/i', $_GET["name"])) {
  die("error");
}

?>

<center>Hello <?php  echo $_GET["name"]; ?></center>

</body>
</html>




