<!DOCTYPE html><!--STATUS OK--><html>
<head>
<meta http-equiv="content-type" content="text/html;charset=utf-8">
<script>
window.alert = function()  
{     
confirm("完成的不错！");
 window.location.href="level15.php?writing=wait"; 
}
</script>
<title>欢迎来到level14</title>
</head>
<body>
<h1 align=center>level14</h1></br>
<h1 align=center>请求参数name</h1>
<script>
	var $a= "<?php  echo $_GET["name"]; ?>";
</script>

</body>
</html>




